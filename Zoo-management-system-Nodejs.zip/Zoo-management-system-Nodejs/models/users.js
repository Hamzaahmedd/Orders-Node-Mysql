'use strict';
const {Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {

    static associate(models) {
      const Ticket = models;
      const Order = models.Order;
      const Country = models.Country;
      User.hasOne(Merchant, {foreignKey: 'admin_id'});
      User.hasMany(Order, {foreignKey: 'user_id'});
      User.belongsTo(Country, { as: 'country', foreignKey: 'country_code' });
    }
  }
  User.init({
    user_name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "first_name should be a string value"
        }
      }
    },
    password: {
      allowNull: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "last_name should be a string value"
        }
      }
    },
    role: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate:{ 
        notEmpty: true,
        isEmail: true
       }
    },
    age: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        isIn: {
          args: [['Male', 'Female', 'Other']],
          msg: "gender should be 'Male', 'Female' or 'Other'"
        }          
      }
    }
  }, {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    underscored: true,
    timestamps: true
  });
  return User;
};