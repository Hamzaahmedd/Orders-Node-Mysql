const express = require('express');
const { getAllTypes, getTypeByID, createType, updateType } = require('../controllers/types');

//Router object
const router = express.Router();

//GET all Types
router.get('/getall', getAllTypes);

//GET Type by ID
router.get('/get/:id', getTypeByID);

//CREATE Type
router.post('/create', createType);

//UPDATE type
router.put('/update/:id', updateType);

module.exports = router;