'use strict';
const { Animal, Cage, Medicine, User } = require('../models');

// GET all Animals
const getAllAnimals = async (req, res) => {
    try {
        const medicine = req.params.medicine_id; let animals;
        if (medicine === null){
             animals = await Animal.findAll({
            where: {
                status: 'Alive'
            },
            include: [
                { model: Cage, as: 'cage'}
            ]
        });

        }else{                    
             animals = await Animal.findAll({
            where: {
                status: 'Alive'
            },
            include: [
                { model: Cage, as: 'cage' },
                { model: Medicine, as: 'medicine' }                             
            ]
        });
        }

        if (!animals || animals.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Animals record',
            totalAnimals: animals.length,
            data: animals
        });

    } catch (error) {
        console.error('Error in GET all animals API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all animals API',
            error: error.message
        });
    }
};

// GET Animal by ID
const getAnimalByID = async (req, res) => {
    const animalID = req.params.id;
    if (!animalID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        let animal; const medicine = req.params.medicine_id;
        
        if(medicine !== null){
            animal = await Animal.findByPk(animalID, {
            include: [
                { model: Cage, as: 'cage' },
                { model: Medicine, as: 'medicine'}
            ]
        });

        }else{
            animal = await Animal.findByPk(animalID, {
            include: [
                { model: Cage, as: 'cage' }
            ]
        });
        }

        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Animal record not found.'
            });
        }

        if (animal.status !== "Alive") {
            return res.status(403).json({
                success: false,
                message: 'Animal is not alive'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Animal Details',
            animalDetails: animal
        });

    } catch (error) {
        console.error('Error in GET animal by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET animal by ID API',
            error: error.message
        });
    }
};

// CREATE Animal
const createAnimal = async (req, res) => {
    const { name, species, cage_id, medicine_id, admin_id, staff_id, status } = req.body;
    if (!name || !species || !cage_id || !admin_id || !staff_id || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if the cage_id exists
        const cage = await Cage.findByPk(cage_id);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'cage_id not found'
            });
        }

        // Check if the staff_id exists
        const staff = await User.findByPk(staff_id);
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'staff_id not found'
            });
        }

        // Check if the admin_id exists
        const admin = await User.findByPk(admin_id);
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'admin_id not found. Animal record can not be created.'
            });
        }

        // Create new user using Sequelize create method
        const newAnimal = await Animal.create({name, species, cage_id, medicine_id, admin_id, 
            staff_id, status});

        res.status(201).json({
            success: true,
            message: 'New animal record created',
            data: newAnimal
        });

    } catch (error) {
        console.error('Error in CREATE animal API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE animal API',
            error: error.message
        });
    }
};

// UPDATE Animal
const updateAnimal = async (req, res) => {
    const animalID = req.params.id;
    if (!animalID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name, species, cage_id, medicine_id, admin_id, staff_id, status } = req.body;
    if (!name || !species || !cage_id || !admin_id || !staff_id || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if the animal ID exists
        const animal = await Animal.findByPk(animalID);
        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Animal record not found'
            });
        }

        // Check if the cage_id exists
        const cage = await Cage.findByPk(cage_id);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'cage_id not found'
            });
        }

        // Check if the staff_id exists
        const staff = await User.findByPk(staff_id);
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'staff_id not found'
            });
        }

        // Check if the admin_id exists
        const admin = await User.findByPk(admin_id);
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'admin_id not found. Animal record can not be created.'
            });
        }

        // Check if the medicine_id exists, if it is not null
        if(medicine_id !== null){
            const medicine = await Medicine.findByPk(medicine_id);
            if(!medicine){
                return res.status(404).json({
                    success: false,
                    message: 'medicine_id not found'
                })
            }
        }
        // Update the animal record using Sequelize
    await animal.update({name, species, cage_id, medicine_id, admin_id, staff_id, status});

        return res.status(200).json({
            success: true,
            message: 'Animal details updated',
            data: animal
        });

    } catch (error) {
        console.error('Error in UPDATE animal API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE animal API',
            error: error.message
        });
    }
};

// PATCH Animal
const patchAnimal = async (req, res) => {
    const animalID = req.params.id;
    if (!animalID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { name, species, cage_id, medicine_id, admin_id, staff_id, status } = req.body;

    try {
        // Check if the animal ID exists
        const animal = await Animal.findByPk(animalID);
        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Animal record not found'
            });
        }
        const fieldsToUpdate = {};

        if (name) {
            fieldsToUpdate.name = name;
        }

        if (species) {
            fieldsToUpdate.species = species;
        }

        if (cage_id) {
        // Check if the cage_id exists
        const cage = await Cage.findByPk(cage_id);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'cage_id not found'
            });
        }
            fieldsToUpdate.cage_id = cage_id;
        }

        if (medicine_id) {
            const medicine = await Medicine.findByPk(medicine_id);
            if(!medicine){
                return res.status(404).json({
                    success: false,
                    message: 'medicine_id not found'
                })
            }
            fieldsToUpdate.medicine_id = medicine_id;
        }

        if (admin_id) {
        // Check if the admin_id exists
        const admin = await User.findByPk(admin_id);
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'admin_id not found. Animal record can not be updated.'
            });
        }
            fieldsToUpdate.admin_id = admin_id;
        }

        if (staff_id) {
        // Check if the staff_id exists
        const staff = await User.findByPk(staff_id);
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'staff_id not found'
            });
        }
            fieldsToUpdate.staff_id = staff_id;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await animal.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Animal details updated',
            data: animal
        });

    } catch (error) {
        console.error('Error in PATCH animal API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH animal API',
            error: error.message
        });
    }
};

module.exports = { getAllAnimals, getAnimalByID, createAnimal, updateAnimal, patchAnimal };
