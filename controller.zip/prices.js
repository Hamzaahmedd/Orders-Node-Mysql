'use strict';
const { Price } = require('../models');

// GET all prices
const getAllPrices = async (req, res) => {
    try {        
        const prices = await Price.findAll();

        if (!prices || prices.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All prices record',
            totalPrices: prices.length,
            data: prices
        });

    } catch (error) {
        console.error('Error in GET all prices API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all prices API',
            error: error.message
        });
    }
};

// GET Price by ID
const getPriceByID = async (req, res) => {
    const priceID = req.params.id;
    if (!priceID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const price = await Price.findByPk(priceID);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Price record not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Price Details',
            priceDetails: price
        });

    } catch (error) {
        console.error('Error in GET price by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET price by ID API',
            error: error.message
        });
    }
};

// CREATE Price
const createPrice = async (req, res) => {
    const { value } = req.body;
    if (!value) {
        return res.status(400).json({
            success: false,
            message: 'Please provide the value fields'
        });
    }

    try {
        // Create new price using Sequelize create method
        const newPrice = await Price.create({value});

        res.status(201).json({
            success: true,
            message: 'New price record created',
            data: newPrice
        });

    } catch (error) {
        console.error('Error in CREATE price API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE price API',
            error: error.message
        });
    }
};

// UPDATE Price
const updatePrice = async (req, res) => {
    const priceID = req.params.id;
    if (!priceID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { price } = req.body;
    if (!price) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        const price = await Price.findByPk(priceID);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Price record not found.'
            });
        }
    
        // Update the price record using Sequelize
    await price.update({value});

        return res.status(200).json({
            success: true,
            message: 'Price details updated',
            data: price
        });

    } catch (error) {
        console.error('Error in UPDATE price API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE price API',
            error: error.message
        });
    }
};

// DELETE Price
const deletePrice = async (req, res) => {
    const priceID = req.params.id;
    
    if (!priceID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const price = await Price.findByPk(priceID);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Price record not found.'
            });
        }

        await price.destroy();
        return res.status(200).json({
            success: true,
            message: 'Price record deleted successfully'
        });

    } catch (error) {
        console.error('Error in DELETE price API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in DELETE price API',
            error: error.message
        });
    }
};

module.exports = { getAllPrices, getPriceByID, createPrice, updatePrice, deletePrice };