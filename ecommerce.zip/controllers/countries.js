'use strict';
const { Country } = require('../models'); 

// GET all Countries
const getAllCountries = async (req, res) => {
  try {
    const countries = await Country.findAll();

    if (!countries || countries.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No records found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "All Countries record",
      totalCountries: countries.length,
      data: countries,
    });
  } catch (error) {
    console.error("Error in GET all countries API:", error);
    return res.status(500).json({
      success: false,
      message: "Error in GET all countries API",
      error: error.message,
    });
  }
};

// GET Country by ID
const getCountryByID = async (req, res) => {
  const countryID = req.params.code;
  if (!countryID) {
    return res.status(400).json({
        success: false,
        message: 'Invalid ID or provide ID'
    });
}

  try {
    const country = await Country.findByPk(countryID);

    if (!country) {
      return res.status(404).json({
        success: false,
        message: "Country not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Country Details",
      countryDetails: country,
    });

  } catch (error) {
    console.error("Error in GET country by ID API:", error);
    return res.status(500).json({
      success: false,
      message: "Error in GET country by ID API",
      error: error.message,
    });
  }
};

// CREATE country
const createCountry = async (req, res) => {
  const { name, continent_name, status } = req.body;
  if (!name || !continent_name || !status) {
    return res.status(400).json({
        success: false,
        message: 'Please provide all the fields'
    });
}

  try {
    // Create a new country record using Sequelize
    const newCountry = await Country.create({
      name,
      continent_name,
      status,
    });

    res.status(201).json({
      success: true,
      message: "New country record created",
      data: newCountry,
    });

  } catch (error) {
    console.error("Error in CREATE country API:", error);
    return res.status(500).json({
      success: false,
      message: "Error in CREATE country API",
      error: error.message,
    });
  }
};

// UPDATE country
const updateCountry = async (req, res) => {
  const countryID = req.params.code;
  if (!countryID) {
    return res.status(400).json({
        success: false,
        message: 'Invalid ID or provide ID'
    });
}
  const { name, continent_name, status } = req.body;
  if (!name || !continent_name || !status) {
    return res.status(400).json({
        success: false,
        message: 'Please provide all the fields'
    });
}

  try {
    const country = await Country.findByPk(countryID);

    if (!country) {
      return res.status(404).json({
        success: false,
        message: "Country not found",
      });
    }

    // Update the country record using Sequelize
    await country.update({
      name,
      continent_name,
      status,
    });

    return res.status(200).json({
      success: true,
      message: "Country details updated",
      data: country,
    });

  } catch (error) {
    console.error("Error in UPDATE country API:", error);
    return res.status(500).json({
      success: false,
      message: "Error in UPDATE country API",
      error: error.message,
    });
  }
};

// PATCH Country
const patchCountry = async (req, res) => {
  const countryID = req.params.code;
  if (!countryID) {
    return res.status(400).json({
        success: false,
        message: 'Invalid ID or provide ID'
    });
}
  const { name, continent_name, status } = req.body;

  try {
    const country = await Country.findByPk(countryID);

    if (!country) {
      return res.status(404).json({
        success: false,
        message: "Country not found",
      });
    }

    // Perform partial update using Sequelize
    await country.update({
      name: name || country.name,
      continent_name: continent_name || country.continent_name,
      status: status || country.status,
    });

    return res.status(200).json({
      success: true,
      message: "Country details updated",
      data: country,
    });

  } catch (error) {
    console.error("Error in PATCH country API:", error);
    return res.status(500).json({
      success: false,
      message: "Error in PATCH country API",
      error: error.message,
    });
  }
};

module.exports = { getAllCountries, getCountryByID, createCountry, updateCountry, patchCountry };