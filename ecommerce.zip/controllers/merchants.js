'use strict';
const { Merchant, User, Country } = require('../models');

// GET all Merchants
const getAllMerchants = async (req, res) => {
    try {
        const merchants = await Merchant.findAll({
            include: [
                {
                    model: User,
                    as: 'admin',
                },
                {
                    model: Country,
                    as: 'country',
                }
            ]
        });

        if (!merchants || merchants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Merchants record',
            totalMerchants: merchants.length,
            data: merchants
        });

    } catch (error) {
        console.error('Error in GET all merchants API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all merchants API',
            error: error.message
        });
    }
};

// GET Merchant by ID
const getMerchantByID = async (req, res) => {
    const merchantID = req.params.id;
    if (!merchantID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const merchant = await Merchant.findByPk(merchantID, {
            include: [
                {
                    model: User,
                    as: 'admin',
                },
                {
                    model: Country,
                    as: 'country',
                }
            ]
        });

        if (!merchant) {
            return res.status(404).json({
                success: false,
                message: 'Merchant not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Merchant Details',
            merchantDetails: merchant
        });

    } catch (error) {
        console.error('Error in GET merchant by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET merchant by ID API',
            error: error.message
        });
    }
};

// CREATE merchant
const createMerchant = async (req, res) => {
    const { merchant_name, admin_id, country_code, status } = req.body;
    if (!merchant_name || !admin_id || !country_code || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if admin_id exists
        const admin = await User.findByPk(admin_id);
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'Admin not found'
            });
        }

        // Check if the country_code exists
        const country = await Country.findByPk(country_code);
        if (!country) {
            return res.status(404).json({
                success: false,
                message: 'Country code not found'
            });
        }

        // Create new merchant using Sequelize create method
        const newMerchant = await Merchant.create({
            merchant_name,
            admin_id,
            country_code, status
        });

        res.status(201).json({
            success: true,
            message: 'New merchant record created',
            data: newMerchant
        });

    } catch (error) {
        console.error('Error in CREATE merchant API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE merchant API',
            error: error.message
        });
    }
};

// UPDATE merchant
const updateMerchant = async (req, res) => {
    const merchantId = req.params.id;
    if (!merchantId) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { merchant_name, admin_id, country_code, status } = req.body;
    if (!merchant_name || !admin_id || !country_code || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if admin_id exists
        const admin = await User.findByPk(admin_id);
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: 'Admin not found'
            });
        }

        // Check if the country_code exists
        const country = await Country.findByPk(country_code);
        if (!country) {
            return res.status(404).json({
                success: false,
                message: 'Country code not found'
            });
        }

        // Check if the merchant ID exists
        const existingMerchant = await Merchant.findByPk(merchantId);
        if (!existingMerchant) {
            return res.status(404).json({
                success: false,
                message: 'Merchant not found'
            });
        }

        // Update merchant using Sequelize save method
        existingMerchant.merchant_name = merchant_name;
        existingMerchant.admin_id = admin_id;
        existingMerchant.country_code = country_code;
        existingMerchant.status = status;
        await existingMerchant.save();

        return res.status(200).json({
            success: true,
            message: 'Merchant details updated',
            data: existingMerchant
        });

    } catch (error) {
        console.error('Error in UPDATE merchant API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE merchant API',
            error: error.message
        });
    }
};

// PATCH merchant
const patchMerchant = async (req, res) => {
    const merchantID = req.params.id;
    if (!merchantID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { merchant_name, admin_id, country_code, status } = req.body;

    try {
        const fieldsToUpdate = {};
        
        if (merchant_name) {
            fieldsToUpdate.merchant_name = merchant_name;
        }

        if (admin_id) {
            // Check if admin_id exists
            const admin = await User.findByPk(admin_id);
            if (!admin) {
                return res.status(404).json({
                    success: false,
                    message: 'Admin not found'
                });
            }
            fieldsToUpdate.admin_id = admin_id;
        }

        if (country_code) {
            // Check if the country code exists
            const country = await Country.findByPk(country_code);
            if (!country) {
                return res.status(404).json({
                    success: false,
                    message: 'Country code not found'
                });
            }
            fieldsToUpdate.country_code = country_code;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Check if the merchant ID exists
        const existingMerchant = await Merchant.findByPk(merchantID);
        if (!existingMerchant) {
            return res.status(404).json({
                success: false,
                message: 'Merchant not found'
            });
        }

        // Perform partial update using Sequelize update method
        await existingMerchant.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Merchant details updated',
            data: existingMerchant
        });

    } catch (error) {
        console.error('Error in PATCH merchant API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH merchant API',
            error: error.message
        });
    }
};

module.exports = { getAllMerchants, getMerchantByID, createMerchant, updateMerchant, patchMerchant };
