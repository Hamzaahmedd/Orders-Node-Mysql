'use strict';
const { Order_Item, Order, Product } = require('../models');

// GET all OrderItems
const getAllOrderItems = async (req, res) => {
    try {
        const orderItems = await Order_Item.findAll({
            include: [
                {
                    model: Order,
                    as: 'order',
                },
                {
                    model: Product,
                    as: 'product',
                }
            ]
        });

        if (!orderItems || orderItems.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All OrderItems record',
            totalOrderItems: orderItems.length,
            data: orderItems
        });

    } catch (error) {
        console.error('Error in GET all order items API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all order items API',
            error: error.message
        });
    }
};

// GET OrderItem by ID
const getOrderItemByID = async (req, res) => {
    const orderItemID = req.params.id;
    if (!orderItemID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const orderItem = await Order_Item.findByPk(orderItemID, {
            include: [
                {
                    model: Order,
                    as: 'order',
                },
                {
                    model: Product,
                    as: 'product',
                }
            ]
        });

        if (!orderItem) {
            return res.status(404).json({
                success: false,
                message: 'Order item not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Order item Details',
            orderItemDetails: orderItem
        });

    } catch (error) {
        console.error('Error in GET order item by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET order item by ID API',
            error: error.message
        });
    }
};

// CREATE OrderItem
const createOrderItem = async (req, res) => {
    const { order_id, product_id, quantity } = req.body;
    if (!order_id || !product_id || !quantity) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if order_id exists
        const order = await Order.findByPk(order_id);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Check if product_id exists
        const product = await Product.findByPk(product_id);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        // Create new order item using Sequelize create method
        const newOrderItem = await Order_Item.create({
            order_id,
            product_id,
            quantity
        });

        res.status(201).json({
            success: true,
            message: 'New order item record created',
            data: newOrderItem
        });

    } catch (error) {
        console.error('Error in CREATE order item API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE order item API',
            error: error.message
        });
    }
};

// UPDATE OrderItem
const updateOrderItem = async (req, res) => {
    const orderItemID = req.params.id;
    if (!orderItemID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { order_id, product_id, quantity } = req.body;
    if (!order_id || !product_id || !quantity) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if order_id exists
        const order = await Order.findByPk(order_id);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Check if product_id exists
        const product = await Product.findByPk(product_id);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        // Check if the order item ID exists
        const existingOrderItem = await Order_Item.findByPk(orderItemID);
        if (!existingOrderItem) {
            return res.status(404).json({
                success: false,
                message: 'Order item not found'
            });
        }

        // Update order item using Sequelize save method
        existingOrderItem.order_id = order_id;
        existingOrderItem.product_id = product_id;
        existingOrderItem.quantity = quantity;
        await existingOrderItem.save();

        return res.status(200).json({
            success: true,
            message: 'Order item details updated',
            data: existingOrderItem
        });

    } catch (error) {
        console.error('Error in UPDATE order item API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE order item API',
            error: error.message
        });
    }
};

// PATCH OrderItem
const patchOrderItem = async (req, res) => {
    const orderItemID = req.params.id;
    if (!orderItemID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { order_id, product_id, quantity } = req.body;

    try {
        const fieldsToUpdate = {};

        if (order_id) {
            // Check if order_id exists
            const order = await Order.findByPk(order_id);
            if (!order) {
                return res.status(404).json({
                    success: false,
                    message: 'Order not found'
                });
            }
            fieldsToUpdate.order_id = order_id;
        }

        if (product_id) {
            // Check if product_id exists
            const product = await Product.findByPk(product_id);
            if (!product) {
                return res.status(404).json({
                    success: false,
                    message: 'Product not found'
                });
            }
            fieldsToUpdate.product_id = product_id;
        }

        if (quantity) {
            fieldsToUpdate.quantity = quantity;
        }

        // Check if the order item ID exists
        const existingOrderItem = await Order_Item.findByPk(orderItemID);
        if (!existingOrderItem) {
            return res.status(404).json({
                success: false,
                message: 'Order item not found'
            });
        }

        // Perform partial update using Sequelize update method
        await existingOrderItem.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Order item details updated',
            data: existingOrderItem
        });

    } catch (error) {
        console.error('Error in PATCH order item API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH order item API',
            error: error.message
        });
    }
};

// DELETE OrderItem
const deleteOrderItem = async (req, res) => {
    const orderItemID = req.params.id;
    
    if (!orderItemID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const orderItem = await Order_Item.findByPk(orderItemID);
        if (!orderItem) {
            return res.status(404).json({
                success: false,
                message: 'Order item not found'
            });
        }

        await orderItem.destroy();
        return res.status(200).json({
            success: true,
            message: 'Order item deleted successfully'
        });

    } catch (error) {
        console.error('Error in DELETE order item API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in DELETE order item API',
            error: error.message
        });
    }
};

module.exports = { getAllOrderItems, getOrderItemByID, createOrderItem, updateOrderItem, patchOrderItem, deleteOrderItem };
