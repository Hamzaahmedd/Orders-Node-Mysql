'use strict';
const { Order, User } = require('../models');

// GET all Orders
const getAllOrders = async (req, res) => {
    try {
        const orders = await Order.findAll({
            include: [
                {
                    model: User,
                    as: 'user',
                }
            ]
        });

        if (!orders || orders.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Orders record',
            totalOrders: orders.length,
            data: orders
        });

    } catch (error) {
        console.error('Error in GET all orders API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all orders API',
            error: error.message
        });
    }
};

// GET Order by ID
const getOrderByID = async (req, res) => {
    const orderID = req.params.id;
    if (!orderID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const order = await Order.findByPk(orderID, {
            include: [
                {
                    model: User,
                    as: 'user',
                }
            ]
        });

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Order Details',
            orderDetails: order
        });

    } catch (error) {
        console.error('Error in GET order by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET order by ID API',
            error: error.message
        });
    }
};

// CREATE Order
const createOrder = async (req, res) => {
    const { user_id, status } = req.body;
    if (!user_id || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if user_id exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Create new order using Sequelize create method
        const newOrder = await Order.create({
            user_id,
            status
        });

        res.status(201).json({
            success: true,
            message: 'New order record created',
            data: newOrder
        });

    } catch (error) {
        console.error('Error in CREATE order API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE order API',
            error: error.message
        });
    }
};

// UPDATE Order
const updateOrder = async (req, res) => {
    const orderID = req.params.id;
    if (!orderID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { user_id, status } = req.body;
    if (!user_id || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    if(status === 'Active' || status === 'Inactive'){}
    else{
        return res.status(400).json({
            success: false,
            message: "status should be 'Active' or 'Inactive'"
        });
    }

    try {
        // Check if user_id exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Check if the order ID exists
        const existingOrder = await Order.findByPk(orderID);
        if (!existingOrder) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Update order using Sequelize save method
        existingOrder.user_id = user_id;
        existingOrder.status = status;
        await existingOrder.save();

        return res.status(200).json({
            success: true,
            message: 'Order details updated',
            data: existingOrder
        });

    } catch (error) {
        console.error('Error in UPDATE order API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE order API',
            error: error.message
        });
    }
};

// PATCH Order
const patchOrder = async (req, res) => {
    const orderID = req.params.id;
    if (!orderID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { user_id, status } = req.body;

    try {
        const fieldsToUpdate = {};

        if (user_id) {
            // Check if user_id exists
            const user = await User.findByPk(user_id);
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'User not found'
                });
            }
            fieldsToUpdate.user_id = user_id;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Check if the order ID exists
        const existingOrder = await Order.findByPk(orderID);
        if (!existingOrder) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Perform partial update using Sequelize update method
        await existingOrder.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Order details updated',
            data: existingOrder
        });

    } catch (error) {
        console.error('Error in PATCH order API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH order API',
            error: error.message
        });
    }
};

module.exports = { getAllOrders, getOrderByID, createOrder, updateOrder, patchOrder };
