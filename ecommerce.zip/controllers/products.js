'use strict';
const { Product, Merchant } = require('../models');

// GET all Products
const getAllProducts = async (req, res) => {
    try {
        const products = await Product.findAll({
            include: [
                {
                    model: Merchant,
                    as: 'merchant'
                }
            ]
        });

        if (!products || products.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Products record',
            totalProducts: products.length,
            data: products
        });

    } catch (error) {
        console.error('Error in GET all products API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all products API',
            error: error.message
        });
    }
};

// GET Product by ID
const getProductByID = async (req, res) => {
    const productID = req.params.id;
    if (!productID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const product = await Product.findByPk(productID, {
            include: [
                {
                    model: Merchant,
                    as: 'merchant',
                }
            ]
        });

        if (!product) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Product Details',
            productDetails: product
        });

    } catch (error) {
        console.error('Error in GET product by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET product by ID API',
            error: error.message
        });
    }
};

// CREATE Product
const createProduct = async (req, res) => {
    const { merchant_id, name, price, status } = req.body;
    if (!name || !price || !status || !merchant_id) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if merchant_id exists
        const merchant = await Merchant.findByPk(merchant_id);
        if (!merchant) {
            return res.status(404).json({
                success: false,
                message: 'Merchant not found'
            });
        }

        // Create new product using Sequelize create method
        const newProduct = await Product.create({
            merchant_id,
            name,
            price,
            status
        });

        res.status(201).json({
            success: true,
            message: 'New product record created',
            data: newProduct
        });

    } catch (error) {
        console.error('Error in CREATE product API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE product API',
            error: error.message
        });
    }
};

// UPDATE Product
const updateProduct = async (req, res) => {
    const productID = req.params.id;
    if (!productID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { merchant_id, name, price, status } = req.body;
    if (!productID || !name || !price || !status || !merchant_id) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or missing fields'
        });
    }

    try {
        // Check if merchant_id exists
        const merchant = await Merchant.findByPk(merchant_id);
        if (!merchant) {
            return res.status(404).json({
                success: false,
                message: 'Merchant not found'
            });
        }

        // Check if the product ID exists
        const existingProduct = await Product.findByPk(productID);
        if (!existingProduct) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        // Update product using Sequelize save method
        existingProduct.merchant_id = merchant_id;
        existingProduct.name = name;
        existingProduct.price = price;
        existingProduct.status = status;
        await existingProduct.save();

        return res.status(200).json({
            success: true,
            message: 'Product details updated',
            data: existingProduct
        });

    } catch (error) {
        console.error('Error in UPDATE product API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE product API',
            error: error.message
        });
    }
};

// PATCH Product
const patchProduct = async (req, res) => {
    const productID = req.params.id;
    if (!productID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { merchant_id, name, price, status } = req.body;

    try {
        const fieldsToUpdate = {};
        
        if (merchant_id) {
            // Check if merchant_id exists
            const merchant = await Merchant.findByPk(merchant_id);
            if (!merchant) {
                return res.status(404).json({
                    success: false,
                    message: 'Merchant not found'
                });
            }
            fieldsToUpdate.merchant_id = merchant_id;
        }

        if (name) {
            fieldsToUpdate.name = name;
        }

        if (price) {
            fieldsToUpdate.price = price;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Check if the product ID exists
        const existingProduct = await Product.findByPk(productID);
        if (!existingProduct) {
            return res.status(404).json({
                success: false,
                message: 'Product not found'
            });
        }

        // Perform partial update using Sequelize update method
        await existingProduct.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Product details updated',
            data: existingProduct
        });

    } catch (error) {
        console.error('Error in PATCH product API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH product API',
            error: error.message
        });
    }
};

module.exports = { getAllProducts, getProductByID, createProduct, updateProduct, patchProduct };
