'use strict';
const { User, Country } = require('../models');

// GET all Users
const getAllUsers = async (req, res) => {
    try {
        const users = await User.findAll({
            include: [
                {
                    model: Country,
                    as: 'country',
                }
            ]
        });

        if (!users || users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Users record',
            totalUsers: users.length,
            data: users
        });

    } catch (error) {
        console.error('Error in GET all users API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all users API',
            error: error.message
        });
    }
};

// GET User by ID
const getUserByID = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }

    try {
        const user = await User.findByPk(userID, {
            include: [
                {
                    model: Country,
                    as: 'country',
                }
            ]
        });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'User Details',
            userDetails: user
        });

    } catch (error) {
        console.error('Error in GET user by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET user by ID API',
            error: error.message
        });
    }
};

// CREATE User
const createUser = async (req, res) => {
    const { full_name, email, gender, date_of_birth, country_code, status } = req.body;
    if (!full_name || !email || !gender || !date_of_birth || !country_code || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Check if the country_code exists
        const country = await Country.findByPk(country_code);
        if (!country) {
            return res.status(404).json({
                success: false,
                message: 'Country code not found'
            });
        }

        // Create new user using Sequelize create method
        const newUser = await User.create({
            full_name,
            email,
            gender,
            date_of_birth,
            country_code, status
        });

        res.status(201).json({
            success: true,
            message: 'New user record created',
            data: newUser
        });

    } catch (error) {
        console.error('Error in CREATE user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE user API',
            error: error.message
        });
    }
};

// UPDATE User
const updateUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { full_name, email, gender, date_of_birth, country_code, status } = req.body;
    if (!userID || !full_name || !email || !gender || !date_of_birth || !country_code || !status) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or missing fields'
        });
    }

    try {
        // Check if the country_code exists
        const country = await Country.findByPk(country_code);
        if (!country) {
            return res.status(404).json({
                success: false,
                message: 'Country code not found'
            });
        }

        // Check if the user ID exists
        const existingUser = await User.findByPk(userID);
        if (!existingUser) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Update user using Sequelize save method
        existingUser.full_name = full_name;
        existingUser.email = email;
        existingUser.gender = gender;
        existingUser.date_of_birth = date_of_birth;
        existingUser.country_code = country_code;
        existingUser.status = status;
        await existingUser.save();

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: existingUser
        });

    } catch (error) {
        console.error('Error in UPDATE user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE user API',
            error: error.message
        });
    }
};

// PATCH User
const patchUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Invalid ID or provide ID'
        });
    }
    const { full_name, email, gender, date_of_birth, country_code, status } = req.body;

    try {
        const fieldsToUpdate = {};

        if (full_name) {
            fieldsToUpdate.full_name = full_name;
        }

        if (email) {
            fieldsToUpdate.email = email;
        }

        if (gender) {
            fieldsToUpdate.gender = gender;
        }

        if (date_of_birth) {
            fieldsToUpdate.date_of_birth = date_of_birth;
        }

        if (country_code) {
            // Check if the country_code exists
            const country = await Country.findByPk(country_code);
            if (!country) {
                return res.status(404).json({
                    success: false,
                    message: 'Country code not found'
                });
            }
            fieldsToUpdate.country_code = country_code;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Check if the user ID exists
        const existingUser = await User.findByPk(userID);
        if (!existingUser) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Perform partial update using Sequelize update method
        await existingUser.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: existingUser
        });

    } catch (error) {
        console.error('Error in PATCH user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH user API',
            error: error.message
        });
    }
};

module.exports = { getAllUsers, getUserByID, createUser, updateUser, patchUser };
