'use strict';
const {Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Country extends Model {

    static associate(models) {
      const Merchant = models.Merchant;
      const User = models.User;
      Country.hasMany(Merchant, { foreignKey: 'country_code' });
      Country.hasMany(User, { foreignKey: 'country_code' });
    }
  }
  Country.init({
    code: {
      type: DataTypes.INTEGER, 
      primaryKey: true, 
      autoIncrement: true, 
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    continent_name: {
      type: DataTypes.ENUM('Africa', 'Antarctica', 'Asia', 'Europe', 'North America', 'Australia', 'South America'),
      allowNull: false, 
      validate:{
        notEmpty: true,
        isIn: {
          args: [['Africa', 'Antarctica', 'Asia', 'Europe', 'North America', 'Australia', 'South America']],
           msg: "Continent name should be either 'Africa', 'Antarctica', 'Asia', 'Europe', 'North America', 'Australia' or 'South America'"
        }
          
      }
    },
    status: {
      type: DataTypes.ENUM("Active", "Inactive"),
      allowNull: false,
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Active", "Inactive"]], msg: "Status should be 'Active' or 'Inactive'"
      }
    }
  }
 
  }, {
    sequelize,
    modelName: 'Country',
    tableName: 'countries',
    underscored: true,
    timestamps: true
  });
  return Country;
};