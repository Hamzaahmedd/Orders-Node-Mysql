'use strict';
const { Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Merchant extends Model {
   
    static associate(models) {
      const Product = models.Product;
      const User = models.User;
      const Country = models.Country;
      Merchant.hasMany(Product, {foreignKey: 'merchant_id'});
      Merchant.belongsTo(User, {as: 'admin', foreignKey: 'admin_id'});
      Merchant.belongsTo(Country, {as: 'country', foreignKey: 'country_code'});
    }
  }
  Merchant.init({
    merchant_name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "merchant_name should be a string value"
        }
      }
    },
    admin_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    country_code: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Active", "Inactive"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Active", "Inactive"]], msg: "Status should be 'Active' or 'Inactive'"
      }
    }
  }
  }, {
    sequelize,
    modelName: 'Merchant',
    tableName: 'merchants',
    underscored: true,
    timestamps: true
  });
  return Merchant;
};