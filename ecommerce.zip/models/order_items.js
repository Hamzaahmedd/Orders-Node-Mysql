'use strict';
const {Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Order_Item extends Model {
  
    static associate(models) {
      const Order = models.Order;
      const Product = models.Product;
      Order_Item.belongsTo(Order, {as: 'order', foreignKey: 'order_id'});
      Order_Item.belongsTo(Product, {as: 'product', foreignKey: 'product_id'});
    }
  }
  Order_Item.init({
    order_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    product_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true,
        isInt: {
          msg: 'quantity must be an integer'
        }
      }
    }
  }, {
    sequelize,
    modelName: 'Order_Item',
    tableName: 'order_items',
    underscored: true,
    timestamps: true
  });
  return Order_Item;
};