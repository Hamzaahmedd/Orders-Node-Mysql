'use strict';
const {Model, DataTypes} = require('sequelize');
const moment = require('moment');
module.exports = (sequelize, DataTypes) => {
  class Order extends Model {
    
    static associate(models) {
      const Order_Item = models.Order_Item;
      const User = models.User;
      Order.hasMany(Order_Item, {foreignKey: 'order_id'});
      Order.belongsTo(User, {as: 'user', foreignKey: 'user_id'});
    }
  }
  Order.init({
    user_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true 
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Active", "Inactive"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Active", "Inactive"]], msg: "Status should be 'Active' or 'Inactive'"
      }
    }
  },
  
  }, {
    sequelize,
    modelName: 'Order',
    tableName: 'orders',
    underscored: true,
    timestamps : true
  });
  return Order;
};