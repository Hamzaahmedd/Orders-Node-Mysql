'use strict';
const {Model, DataTypes} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Product extends Model {
   
    static associate(models) {
      const Merchant = models.Merchant;
      const Order_Item = models.Order_Item;
      Product.hasMany(Order_Item, {foreignKey: 'product_id'});
      Product.belongsTo(Merchant, {as: 'merchant', foreignKey: 'merchant_id'});
    }
  }
  Product.init({
    merchant_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    price: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate:{
        notEmpty: true,
        min: {
          args: 1,
          msg: 'price must be at least RS 1', 
        }, 
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Active", "Inactive"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Active", "Inactive"]], msg: "Status should be 'Active' or 'Inactive'"
      }
    }
  }
  }, {
    sequelize,
    modelName: 'Product',
    tableName: 'products',
    underscored: true,
    timestamps: true
  });
  return Product;
};