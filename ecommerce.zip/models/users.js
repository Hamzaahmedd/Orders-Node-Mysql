'use strict';
const {Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {

    static associate(models) {
      const Merchant = models.Merchant;
      const Order = models.Order;
      const Country = models.Country;
      User.hasMany(Merchant, {foreignKey: 'admin_id'});
      User.hasMany(Order, {foreignKey: 'user_id'});
      User.belongsTo(Country, { as: 'country', foreignKey: 'country_code' });
    }
  }
  User.init({
    first_name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "first_name should be a string value"
        }
      }
    },
    last_name: {
      allowNull: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "last_name should be a string value"
        }
      }
    },
    email: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate:{ 
        notEmpty: true,
        isEmail: true
       }
    },
    gender: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        isIn: {
          args: [['Male', 'Female', 'Other']],
          msg: "gender should be 'Male', 'Female' or 'Other'"
        }          
      }
    },
    date_of_birth: {
      allowNull: false,
      type: DataTypes.DATEONLY,
      validate:{
        notEmpty: true,
        isDate: true,
        isBefore: new Date()
      }
    },
    country_code: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Active", "Inactive"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Active", "Inactive"]], msg: "Status should be 'Active' or 'Inactive'"
      }
    }
  }
  }, {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    underscored: true,
    timestamps: true
  });
  return User;
};