const express = require('express');
const { getAllCountries, getCountryByID, createCountry, updateCountry, patchCountry } = require('../controllers/countries');

//Router object
const router = express.Router();

//GET all countries
router.get('/getall', getAllCountries);

//GET country by ID
router.get('/get/:code', getCountryByID);

//CREATE country
router.post('/create', createCountry);

//UPDATE country
router.put('/update/:code', updateCountry);

//PATCH country
router.patch('/patch/:code', patchCountry);

module.exports = router;