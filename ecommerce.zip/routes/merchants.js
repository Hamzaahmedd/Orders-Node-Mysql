const express = require('express');
const {getAllMerchants, getMerchantByID, createMerchant, updateMerchant, patchMerchant } = require('../controllers/merchants');

//Router object
const router = express.Router();

//GET all merchants
router.get('/getall', getAllMerchants);

//GET merchant by ID
router.get('/get/:id', getMerchantByID);

//CREATE merchant
router.post('/create', createMerchant);

//UPDATE merchant
router.put('/update/:id', updateMerchant);

//PATCH merchant
router.patch('/patch/:id', patchMerchant);

module.exports = router;