const express = require('express');
const {getAllOrderItems, getOrderItemByID, createOrderItem, updateOrderItem, patchOrderItem, deleteOrderItem } = require('../controllers/order_items');

//Router object
const router = express.Router();

//GET all Order Items
router.get('/getall', getAllOrderItems);

//GET Order Item by ID
router.get('/get/:id', getOrderItemByID);

//CREATE Order Item
router.post('/create', createOrderItem);

//UPDATE Order Item
router.put('/update/:id', updateOrderItem);

//PATCH Order Item
router.patch('/patch/:id', patchOrderItem);

//DELETE order item
router.delete('/delete/:id', deleteOrderItem);

module.exports = router;