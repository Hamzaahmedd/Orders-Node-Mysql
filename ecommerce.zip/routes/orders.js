const express = require('express');
const { getAllOrders, getOrderByID, createOrder, updateOrder, patchOrder } = require('../controllers/orders');

//Router object
const router = express.Router();

//GET all orders
router.get('/getall', getAllOrders);

//GET order by ID
router.get('/get/:id', getOrderByID);

//CREATE order
router.post('/create', createOrder);

//UPDATE order
router.put('/update/:id', updateOrder);

//PATCH order
router.patch('/patch/:id', patchOrder);

module.exports = router;