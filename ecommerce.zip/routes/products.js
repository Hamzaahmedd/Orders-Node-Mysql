const express = require('express');
const {getAllProducts, getProductByID, createProduct, updateProduct, patchProduct } = require('../controllers/products');

//Router object
const router = express.Router();

//GET all Products
router.get('/getall', getAllProducts);

//GET Product by ID
router.get('/get/:id', getProductByID);

//CREATE Product
router.post('/create', createProduct);

//UPDATE Product
router.put('/update/:id', updateProduct);

//PATCH Product
router.patch('/patch/:id', patchProduct);

module.exports = router;