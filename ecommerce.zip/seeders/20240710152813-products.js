'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const productsData = [
      { merchant_id: 1, name: 'TV', price: 1000, status: 'Active' },
      { merchant_id: 2, name: 'PC', price: 1500, status: 'Active' },
      { merchant_id: 3, name: 'Laptop', price: 1200, status: 'Active' }
      // Add more products as needed
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('products', productsData, {});
  },

  async down (queryInterface, Sequelize) {
     // Remove inserted data if needed
     await queryInterface.bulkDelete('products', null, {});
  }
};
