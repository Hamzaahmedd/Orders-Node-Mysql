'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const countriesData = [
      { name: 'Pakistan', continent_name: "Asia", status: 'Active' },
      { name: 'Japan', continent_name: "Asia", status: 'Active' },
      { name: 'Germany', continent_name: "Europe", status: 'Active' }
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('countries', countriesData, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('countries', null, {});
  }
};
