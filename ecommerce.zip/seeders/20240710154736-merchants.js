'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const merchantsData = [
      { merchant_name: "Ahmed", admin_id: 1, country_code: 1, status: 'Active' },
      { merchant_name: "Ali", admin_id: 1, country_code: 2, status: 'Active' },
      { merchant_name: "Hasan", admin_id: 1, country_code: 3, status: 'Active' }
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('merchants', merchantsData, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('merchants', null, {});
  }
};
