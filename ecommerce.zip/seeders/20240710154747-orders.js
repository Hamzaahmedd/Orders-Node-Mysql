'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const ordersData = [
      { user_id: 1, status: 'Active' },
      { user_id: 2, status: 'Active' },
      { user_id: 3, status: 'Active' }
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('orders', ordersData, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('orders', null, {});
  }
};
