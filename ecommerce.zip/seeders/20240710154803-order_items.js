'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const orderItemsData = [
      { order_id: 1, product_id: 1, quantity: 22 },
      { order_id: 2, product_id: 2, quantity: 15 },
      { order_id: 3, product_id: 3, quantity: 10 }
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('order_items', orderItemsData, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('order_items', null, {});
  }
};
