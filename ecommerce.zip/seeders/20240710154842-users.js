'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const usersData = [
      { first_name: "Hamza", last_name: "Ahmed", email: "hamza.ahmed@user.com", gender: "Male", date_of_birth: "1990-04-09", country_code: 1, status: 'Active' },
      { first_name: "Ruhan", last_name: "Ahmed", email: "ruhan.ahmed@user.com", gender: "Male", date_of_birth: "1990-07-08", country_code: 2, status: 'Active' },
      { first_name: "Jalil", last_name: "Ahmed", email: "jalil.ahmed@user.com", gender: "Male", date_of_birth: "1990-06-02", country_code: 3, status: 'Active' }
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('users', usersData, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('users', null, {});
  }
};
