const express = require('express');
const colors = require('colors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const mySqlPool = require('./config/db');
const {check, validationResult} = require('express-validator');

//configure dotenv
dotenv.config();

//rest object
const app = express();

//middlewares
app.use(express.json());
app.use(morgan("dev"));

//routes
app.use('/api/v1/orders', require('./routes/orders'));
app.use('/api/v1/users', require('./routes/users'));
app.use('/api/v1/countries', require('./routes/countries'));
app.use('/api/v1/merchants', require('./routes/merchants'));
app.use('/api/v1/products', require('./routes/products'));
app.use('/api/v1/order_items', require('./routes/order_items'));
app.get("/test", (req, res) => {
    return res.status(200).send("<h1>Orders Nodejs Mysql</h1>");
});
app.use((req, res, next) => {
    res.status(404).json({
        success: false,
        message: 'Route not found'
    });
});

//port
const PORT = process.env.PORT || 8000;

//conditionally listen
mySqlPool.query("SELECT 1").then(() => {
//MY SQL
console.log('MySQL DB connected'.bgCyan.white);
//listen
app.listen(PORT, () => {
    console.log(`Server Running on port ${process.env.PORT}`.bgMagenta.white);
});
}).catch((error) => {
    console.log('error');
});