'use strict';
const { Medicine } = require('../models');

// GET all Medicines
const getAllMedicines = async (req, res) => {
    try {        
        const medicines = await Medicine.findAll();

        if (!medicines || medicines.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All medicines record',
            totalMedicines: medicines.length,
            data: medicines
        });

    } catch (error) {
        console.error('Error in GET all medicines API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all medicines API',
            error: error.message
        });
    }
};

// GET Medicine by ID
const getMedicineByID = async (req, res) => {
    const medicineID = req.params.id;
    if (!medicineID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const medicine = await Medicine.findByPk(medicineID);
        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Medicine record not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Medicine Details',
            medicineDetails: medicine
        });

    } catch (error) {
        console.error('Error in GET medicine by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET medicine by ID API',
            error: error.message
        });
    }
};

// CREATE Medicine
const createMedicine = async (req, res) => {
    const { name, purpose, quantity } = req.body;

    try {
        const existingName = await Medicine.findOne({ where: { name } });
        if (existingName) {
            return res.status(400).json({
                success: false,
                message: 'name must be unique'
            });
        }
        // Create new medicine using Sequelize create method
        const newMedicine = await Medicine.create({name, purpose, quantity});

        res.status(201).json({
            success: true,
            message: 'New medicine record created',
            data: newMedicine
        });

    } catch (error) {
        console.error('Error in CREATE medicine API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE medicine API',
                error: error.message
            });
          } 
    }
};

// UPDATE Medicine
const updateMedicine = async (req, res) => {
    const medicineID = req.params.id;
    if (!medicineID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name, purpose, quantity } = req.body;
    
    try {
        const medicine = await Medicine.findByPk(medicineID);
        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Medicine record not found.'
            });
        }
    
        if (name && name !== medicine.name) {
            const existingMedicine = await Medicine.findOne({ where: { name } });
            if (existingMedicine && existingMedicine.id !== medicineID) {
                return res.status(400).json({
                    success: false,
                    message: 'name must be unique'
                });
            }
        }

        // Update the medicine record using Sequelize
    await medicine.update({name, purpose, quantity});

        return res.status(200).json({
            success: true,
            message: 'Medicine details updated',
            data: medicine
        });

    } catch (error) {
        console.error('Error in UPDATE medicine API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE medicine API',
                error: error.message
            });
          } 
    }
};

// PATCH Medicine
const patchMedicine = async (req, res) => {
    const medicineID = req.params.id;
    if (!medicineID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { name, purpose, quantity } = req.body;

    try {
        const medicine = await Medicine.findByPk(medicineID);
        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Medicine record not found.'
            });
        }

        const fieldsToUpdate = {};

        if (name) {
            const existingMedicine = await Medicine.findOne({ where: { name } });
            if (existingMedicine && existingMedicine.id !== medicineID) {
                return res.status(400).json({
                    success: false,
                    message: 'name must be unique'
                });
            }
            fieldsToUpdate.name = name;
        }

        if (purpose) {
            fieldsToUpdate.purpose = purpose;
        }

        if (quantity) {
            fieldsToUpdate.quantity = quantity;
        }

        // Perform partial update using Sequelize update method
        await medicine.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Medicine details updated',
            data: medicine
        });

    } catch (error) {
        console.error('Error in PATCH medicine API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH medicine API',
                error: error.message
            });
          } 
    }
};

// DELETE Medicine
const deleteMedicine = async (req, res) => {
    const medicineID = req.params.id;
    
    if (!medicineID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const medicine = await Medicine.findByPk(medicineID);
        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Medicine record not found.'
            });
        }

        await medicine.destroy();
        return res.status(200).json({
            success: true,
            message: 'Medicine record deleted successfully'
        });

    } catch (error) {
        console.error('Error in DELETE medicine API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in DELETE medicine API',
            error: error.message
        });
    }
};

module.exports = { getAllMedicines, getMedicineByID, createMedicine, updateMedicine, patchMedicine, deleteMedicine };