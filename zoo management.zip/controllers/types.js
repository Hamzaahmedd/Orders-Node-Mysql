'use strict';
const { Type } = require('../models');

// GET all Types
const getAllTypes = async (req, res) => {
    try {        
        const types = await Type.findAll();

        if (!types || types.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All types record',
            totalTypes: types.length,
            data: types
        });

    } catch (error) {
        console.error('Error in GET all types API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all types API',
            error: error.message
        });
    }
};

// GET Type by ID
const getTypeByID = async (req, res) => {
    const typeID = req.params.id;
    if (!typeID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const type = await Type.findByPk(typeID);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Type record not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Type Details',
            typeDetails: type
        });

    } catch (error) {
        console.error('Error in GET type by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET type by ID API',
            error: error.message
        });
    }
};

// CREATE Type
const createType = async (req, res) => {
    const { name } = req.body;

    try {
        const existingType = await Type.findOne({ where: { name } });
        if (existingType) {
            return res.status(400).json({
                success: false,
                message: 'name must be unique'
            });
        }

        // Create new type using Sequelize create method
        const newType = await Type.create({name});

        res.status(201).json({
            success: true,
            message: 'New type record created',
            data: newType
        });

    } catch (error) {
        console.error('Error in CREATE type API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            if (error.name === 'SequelizeValidationError') {
                res.status(400).json({
                  success: false,
                  message: error.errors.map(e => e.message).join(', ')
                });
              } else{
                return res.status(500).json({
                    success: false,
                    message: 'Error in CREATE type API',
                    error: error.message
                });
              } 
          } 
    }
};

// UPDATE Type
const updateType = async (req, res) => {
    const typeID = req.params.id;
    if (!typeID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name } = req.body;

    try {
        const type = await Type.findByPk(typeID);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Type record not found.'
            });
        }
    
        if (name && name !== type.name) {
            const existingType = await Type.findOne({ where: { name } });
            if (existingType && existingType.id !== typeID) {
                return res.status(400).json({
                    success: false,
                    message: 'name must be unique'
                });
            }
        }

        // Update the type record using Sequelize
    await type.update({name});

        return res.status(200).json({
            success: true,
            message: 'Type details updated',
            data: type
        });

    } catch (error) {
        console.error('Error in UPDATE type API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE type API',
                error: error.message
            });
          } 
    }
};

// DELETE Type
const deleteType = async (req, res) => {
    const typeID = req.params.id;
    
    if (!typeID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const type = await Type.findByPk(typeID);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Type record not found.'
            });
        }

        await type.destroy();
        return res.status(200).json({
            success: true,
            message: 'Type record deleted successfully'
        });

    } catch (error) {
        console.error('Error in DELETE type API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in DELETE type API',
            error: error.message
        });
    }
};

module.exports = { getAllTypes, getTypeByID, createType, updateType, deleteType };