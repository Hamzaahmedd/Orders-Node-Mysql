'use strict';
const { User } = require('../models');

// GET all Users
const getAllUsers = async (req, res) => {
    try {        
        const users = await User.findAll();

        if (!users || users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Users record',
            totalUsers: users.length,
            data: users
        });

    } catch (error) {
        console.error('Error in GET all users API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all users API',
            error: error.message
        });
    }
};

// GET User by ID
const getUserByID = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'User Details',
            userDetails: user
        });

    } catch (error) {
        console.error('Error in GET user by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET user by ID API',
            error: error.message
        });
    }
};

// CREATE User
const createUser = async (req, res) => {
    const { name, age, role, status } = req.body;
    if (!name || !age || !role || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }

    try {
        // Create new user using Sequelize create method
        const newUser = await User.create({name, age, role, status});

        res.status(201).json({
            success: true,
            message: 'New user record created',
            data: newUser
        });

    } catch (error) {
        console.error('Error in CREATE user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in CREATE user API',
            error: error.message
        });
    }
};

// UPDATE User
const updateUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name, age, role, status } = req.body;
    if (!name || !age || !role || !status) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all the fields'
        });
    }


    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }
    
        // Update the user record using Sequelize
    await user.update({name, age, role, status});

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in UPDATE user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in UPDATE user API',
            error: error.message
        });
    }
};

// PATCH User
const patchUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { name, age, role, status } = req.body;

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }

        const fieldsToUpdate = {};

        if (name) {
            fieldsToUpdate.name = name;
        }

        if (age) {
            fieldsToUpdate.age = age;
        }

        if (role) {
            fieldsToUpdate.role = role;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await user.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in PATCH user API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in PATCH user API',
            error: error.message
        });
    }
};

module.exports = { getAllUsers, getUserByID, createUser, updateUser, patchUser };