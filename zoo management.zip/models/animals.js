'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Animal extends Model {
    static associate(models) {
      const Medicine = models.Medicine;
      const Cage = models.Cage;
      const Feeding_schedule = models.Feeding_schedule;
      Animal.hasMany(Medicine, {foreignKey: 'medicine_id'});
      Animal.hasOne(Cage, {foreignKey: "cage_id"});
      Animal.belongsTo(Feeding_schedule, {as: "animal", foreignKey: "animal_id"});
    }
  }
  Animal.init({
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    species: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    cage_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    medicine_id: {
      allowNull: true,
      type: DataTypes.INTEGER
    },
    admin_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    staff_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Alive", "Not Alive"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Alive", "Not Alive"]], msg: "status should be 'Alive' or 'Not Alive'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Animal',
    tableName: 'animals',
    underscored: true,
    timestamps: true
  });
  return Animal;
};