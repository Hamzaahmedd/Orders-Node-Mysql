'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Cage extends Model {
    static associate(models) {
      const Animal = models.Animal;
      Cage.hasMany(Animal, {foreignKey: "cage_id"});
    }
  } 
  Cage.init({
    cage_number: {
      allowNull: false,
      type: DataTypes.INTEGER,
      unique: {
        args: true,
        msg: 'cage_number must be unique'
      },
      validate: {
        notNull: {
          msg: 'cage_number is a required field'
        },
        notEmpty: {
          msg: 'cage_number cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'cage_number must be an integer' 
        },
        min: {
          args: [1],
          msg: 'cage_number cannot be less than 1' 
        },
      }
    },
    capacity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'capacity is a required field'
        },
        notEmpty: {
          msg: 'capacity cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'capacity must be an integer' 
        },
        min: {
          args: [1],
          msg: 'capacity cannot be less than 1' 
        },
      }
    },
  }, {
    sequelize,
    modelName: 'Cage',
    tableName: 'cages',
    timestamps: true
  });
  return Cage;
};