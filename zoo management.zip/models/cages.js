'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Cage extends Model {
    static associate(models) {
      const Animal = models.Animal;
      Cage.belongsTo(Animal, {as: "cage", foreignKey: "cage_id"});
    }
  }
  Cage.init({
    cage_number: {
      allowNull: false,
      unique: true,
      type: DataTypes.INTEGER,
    },
    capacity: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER
    }
  }, {
    sequelize,
    modelName: 'Cage',
    tableName: 'cages',
    underscored: true,
    timestamps: true
  });
  return Cage;
};