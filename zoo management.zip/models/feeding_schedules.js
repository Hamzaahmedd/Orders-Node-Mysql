'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Feeding_schedule extends Model {
    static associate(models) {
      const Animal = models.Animal;
      const Food_item = models.Food_item;
      Feeding_schedule.belongsTo(Animal, {as: "animal", foreignKey: 'animal_id'});
      Feeding_schedule.hasMany(Food_item, {foreignKey: "food_id"});
    }
  }
  Feeding_schedule.init({
    animal_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'animal_id is a required field'
        },
        notEmpty: {
          msg: 'animal_id cannot be empty'
        },
      }
    },
    time: {
      allowNull: false,
      type: DataTypes.TIME,
      validate: {
        notNull: {
          msg: 'time is a required field'
        },
        notEmpty: {
          msg: 'time cannot be empty'
        },
        is: {
          args: /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/,
          msg: 'time must be in HH:MM format'
        },
      }
    },
    food_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'food_id is a required field'
        },
        notEmpty: {
          msg: 'food_id cannot be empty'
        },
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Pending", "Completed"),
      validate: {
        notNull: {
          msg: 'status is a required field'
        },
        notEmpty: {
          msg: 'status cannot be empty'
        },
        isIn: {
          args: [["Pending", "Completed"]], msg: "status should be 'Pending' or 'Completed'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Feeding_schedule',
    tableName: 'feeding_schedules',
    timestamps: true
  });
  return Feeding_schedule;
};