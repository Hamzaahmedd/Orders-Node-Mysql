'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Feeding_schedule extends Model {
    static associate(models) {
      const Animal = models.Animal;
      const Food_item = models.Food_item;
      const Feeding_schedule = models.Feeding_schedule;
      Feeding_schedule.hasMany(Animal, {foreignKey: 'animal_id'});
      Feeding_schedule.hasOne(Food_item, {foreignKey: "cage_id"});
    }
  }
  Feeding_schedule.init({
    animal_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    time: {
      allowNull: false,
      type: DataTypes.TIME,
      is: {
        args: /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/,
        msg: 'time must be in HH:MM format'
      }
    },
    food_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Pending", "Completed"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Pending", "Completed"]], msg: "status should be 'Pending' or 'Completed'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Feeding_schedule',
    tableName: 'feeding_schedules',
    underscored: true,
    timestamps: true
  });
  return Feeding_schedule;
};