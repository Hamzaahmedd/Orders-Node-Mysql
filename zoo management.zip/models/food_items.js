'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Food_item extends Model {
    static associate(models) {
      const Type = models.Type;
      const Feeding_schedule = models.Feeding_schedule;
      Food_item.hasOne(Type, {foreignKey: "type_id"});
      Food_item.belongsTo(Feeding_schedule, {as: "food", foreignKey: "food_id"});
    }
  }
  Food_item.init({
    name: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      } 
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    type_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Available", "Not Available"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Available", "Not Available"]], msg: "status should be 'Available' or 'Not Available'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Food_item',
    tableName: 'food_items',
    underscored: true,
    timestamps: true
  });
  return Food_item;
};