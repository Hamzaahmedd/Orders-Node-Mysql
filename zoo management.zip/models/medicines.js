'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Medicine extends Model {
    static associate(models) {
      const Animal = models.Animal;
      Medicine.belongsTo(Animal, {as: "medicine", foreignKey: "medicine_id"});
    }
  }
  Medicine.init({
    name: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    purpose: {
      allowNull: false,
      unique: true,
      type: DataTypes.TEXT,
      validate: {
        notEmpty: true,
        len: {
          args: [1, 1000],
          msg: 'purpose must be between 1 and 1000 characters'
        }
      }
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER
    }
  }, {
    sequelize,
    modelName: 'Medicine',
    tableName: 'medicines',
    underscored: true,
    timestamps: true
  });
  return Medicine;
};