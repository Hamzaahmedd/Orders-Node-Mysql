'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Price extends Model {
    static associate(models) {
      const Ticket = models.Ticket;
      Price.belongsTo(Ticket, {as: "price", foreignKey: "price_id"});
    }
  }
  Price.init({
    value: {
      allowNull: false,
      unique: true,
      type: DataTypes.DECIMAL(10, 2),
      validate:{
        notEmpty: true,
        isDecimal: {
          msg: 'value must be a decimal number'
        },
        min: {  
          args: 0.01,
          msg: 'value must be at least 0.01', 
        }, 
      }
    }
  }, {
    sequelize,
    modelName: 'Price',
    tableName: 'prices',
    underscored: true,
    timestamps: true
  });
  return Price;
};