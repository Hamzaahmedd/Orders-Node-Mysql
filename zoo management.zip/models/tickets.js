'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Ticket extends Model {
    static associate(models) {
      const User = models.User;
      const Price = models.Price;
      Ticket.hasOne(User, {foreignKey: "user_id"});
      Ticket.hasMany(Price, {foreignKey: "price_id"});
    }
  }
  Ticket.init({
    user_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    price_id: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    issue_time: {
      allowNull: false,
      type: DataTypes.DATE
    },
    expiry_time: {
      allowNull: false,
      type: DataTypes.DATE
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Issued", "Expired"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Issued", "Expired"]], msg: "status should be 'Issued' or 'Expired'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Ticket',
    tableName: 'tickets',
    underscored: true,
    timestamps: true
  });
  return Ticket;
};