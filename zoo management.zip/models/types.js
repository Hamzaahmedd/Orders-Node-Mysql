'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Type extends Model {
    static associate(models) {
      const Food_item = models.Food_item;
      Type.belongsTo(Food_item, {as: "type", foreignKey: "type_id"});
    }
  }
  Type.init({
    name: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    }
  }, {
    sequelize,
    modelName: 'Type',
    tableName: 'types',
    underscored: true,
    timestamps: true
  });
  return Type;
};