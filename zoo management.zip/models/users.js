'use strict';
const {Model, DataTypes} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    static associate(models) {
      const Ticket = models;
      const Animal = models.Animal;
      User.belongsTo(Ticket, { as: 'user', foreignKey: 'user_id'});
      User.belongsTo(Animal, {as: "admin", foreignKey: "admin_id"});
      User.belongsTo(Animal, {as: "staff", foreignKey: "staff_id"});
    }
  }
  User.init({
    email: {
      allowNull: false,
      unique: true,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        isEmail: true
      }
    },
    password: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        len: {
          args: [8, 100],
          msg: 'password must be at least 8 characters long'
        }
      }
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notEmpty: true,
        is: {
          args: ["^[a-z]+$",'i'],
          msg: "name should be a string value"
        }
      }
    },
    age: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: true
      }
    },
    role: {
      allowNull: false,
      type: DataTypes.ENUM("Admin", "Staff", "User"),
      validate: {
        notEmpty: true,
        isIn: {
          args: [["Admin", "Staff", "User"]], msg: "role should be 'Admin', 'Staff' or 'User'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    underscored: true,
    timestamps: true
  });
  return User;
};