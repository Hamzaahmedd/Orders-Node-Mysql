const express = require('express');
const { getAllAnimals, getAnimalByID, createAnimal, updateAnimal, patchAnimal } = require('../controllers/animals');

//Router object
const router = express.Router();

//GET all animals
router.get('/getall', getAllAnimals);

//GET animal by ID
router.get('/get/:id', getAnimalByID);

//CREATE animal
router.post('/create', createAnimal);

//UPDATE animal
router.put('/update/:id', updateAnimal);

//PATCH animal
router.patch('/patch/:id', patchAnimal);

module.exports = router;