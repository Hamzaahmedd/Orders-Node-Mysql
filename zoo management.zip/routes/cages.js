const express = require('express');
const { getAllCages, getCageByID, createCage, updateCage, patchCage, deleteCage } = require('../controllers/cages');

//Router object
const router = express.Router();

//GET all cages
router.get('/getall', getAllCages);

//GET cage by ID
router.get('/get/:id', getCageByID);

//CREATE cage
router.post('/create', createCage);

//UPDATE cage
router.put('/update/:id', updateCage);

//PATCH cage
router.patch('/patch/:id', patchCage);

//DELETE cage
router.delete('/delete/:id', deleteCage);

module.exports = router;