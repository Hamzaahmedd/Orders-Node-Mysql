const express = require('express');
const { getAllCapacities, getCapacityByID, createCapacity, updateCapacity } = require('../controllers/capacities');

//Router object
const router = express.Router();

//GET all Capacity
router.get('/getall', getAllCapacities);

//GET Capacity by ID
router.get('/get/:id', getCapacityByID);

//CREATE Capacity
router.post('/create', createCapacity);

//UPDATE Capacity
router.put('/update/:id', updateCapacity);

module.exports = router;