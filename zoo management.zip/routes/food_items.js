const express = require('express');
const { getAllFoodItems, getFoodItemByID, createFoodItem, updateFoodItem, patchFoodItem } = require('../controllers/food_items');

//Router object
const router = express.Router();

//GET all FoodItems
router.get('/getall', getAllFoodItems);

//GET FoodItem by ID
router.get('/get/:id', getFoodItemByID);

//CREATE FoodItem
router.post('/create', createFoodItem);

//UPDATE FoodItem
router.put('/update/:id', updateFoodItem);

//PATCH FoodItem
router.patch('/patch/:id', patchFoodItem);

module.exports = router;