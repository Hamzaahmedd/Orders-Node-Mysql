const express = require('express');
const { getAllPrices, getPriceByID, createPrice, updatePrice, deletePrice } = require('../controllers/prices');

//Router object
const router = express.Router();

//GET all animals
router.get('/getall', getAllPrices);

//GET animal by ID
router.get('/get/:id', getPriceByID);

//CREATE animal
router.post('/create', createPrice);

//UPDATE animal
router.put('/update/:id', updatePrice);

//DELETE animal
router.delete('/delete/:id', deletePrice);

module.exports = router;