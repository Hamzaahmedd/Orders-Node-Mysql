'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const usersData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('users', usersData, {});
  },

  async down (queryInterface, Sequelize) {
   // Remove inserted data if needed
   await queryInterface.bulkDelete('users', null, {});
  }
};
