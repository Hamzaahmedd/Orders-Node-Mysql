'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const ticketsData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('tickets', ticketsData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('tickets', null, {});
  }
};
