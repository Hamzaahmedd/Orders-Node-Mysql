'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const feeding_schedulesData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('feeding_schedules', feeding_schedulesData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('feeding_schedules', null, {});
  }
};
