const express = require('express');
const colors = require('colors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const mySqlPool = require('./config/db');

//configure dotenv
dotenv.config();

//rest object
const app = express();

//middlewares
app.use(express.json());
app.use(morgan("dev"));

//routes
app.use('/api/v1/animals', require('./routes/animals'));
app.use('/api/v1/cages', require('./routes/cages'));
app.use('/api/v1/feeding_schedules', require('./routes/feeding_schedules'));
app.use('/api/v1/food_items', require('./routes/food_items'));
app.use('/api/v1/medicines', require('./routes/medicines'));
app.use('/api/v1/prices', require('./routes/prices'));
app.use('/api/v1/tickets', require('./routes/tickets'));
app.use('/api/v1/types', require('./routes/types'));
app.use('/api/v1/users', require('./routes/users'));
app.get("/test", (req, res) => {
    return res.status(200).send("<h1>Zoo Nodejs Mysql</h1>");
});
app.use((req, res, next) => {
    res.status(404).json({
        success: false,
        message: 'Route not found'
    });
});

//port
const PORT = process.env.PORT || 8000;

//conditionally listen
mySqlPool.query("SELECT 1").then(() => {
//MY SQL
console.log('MySQL DB connected'.bgCyan.white);
//listen
app.listen(PORT, () => {
    console.log(`Server Running on port ${process.env.PORT}`.bgMagenta.white);
});
}).catch((error) => {
    console.log('error');
});